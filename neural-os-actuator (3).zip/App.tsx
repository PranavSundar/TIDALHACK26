
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Type, FunctionDeclaration } from '@google/genai';
import { CommandLog } from './types';
import AudioVisualizer from './components/AudioVisualizer';
import Sidebar from './components/Sidebar';
import { decode, encode, decodeAudioData } from './utils/audio';

declare global {
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }
  interface Window {
    aistudio?: AIStudio;
  }
}

const kernelTools: FunctionDeclaration[] = [
  {
    name: 'actuate',
    description: 'KERNEL ACTUATOR BRIDGE: Execute system commands, vision analysis, media production, or playback workflows.',
    parameters: {
      type: Type.OBJECT,
      properties: {
        action: { 
          type: Type.STRING, 
          enum: ['LAUNCH', 'SYSTEM', 'BROWSER', 'TYPE', 'VISION_DESCRIBE', 'VIDEO_BUILD'],
          description: 'Operational category.' 
        },
        stage: {
          type: Type.STRING,
          enum: ['STORYBOARD', 'ASSETS', 'RENDER'],
          description: 'Current phase of the VIDEO_BUILD process.'
        },
        exec: { 
          type: Type.STRING, 
          description: 'URI, shell command, search query, or target path.' 
        },
        name: {
          type: Type.STRING,
          description: 'Target entity name.'
        },
        feedback: { 
          type: Type.STRING, 
          description: 'Auditory feedback or description.' 
        },
        assets: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: 'Media asset URIs or stock footage search links.'
        },
        elements: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              type: { type: Type.STRING },
              label: { type: Type.STRING },
              content: { type: Type.STRING },
              location: { type: Type.STRING }
            }
          },
          description: 'UI elements for VISION_DESCRIBE.'
        }
      },
      required: ['action', 'feedback']
    }
  }
];

const JPEG_QUALITY = 0.4;

const App: React.FC = () => {
  const [logs, setLogs] = useState<CommandLog[]>([
    { timestamp: new Date(), type: 'system', message: 'ROOT_KERNEL: LOADED.' }
  ]);
  const [isListening, setIsListening] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isActuating, setIsActuating] = useState(false);
  const [isBooting, setIsBooting] = useState(true);
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const [ariaStatus, setAriaStatus] = useState('ACTUATOR STANDBY');

  const sessionPromiseRef = useRef<Promise<any> | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(document.createElement('canvas'));
  const frameIntervalRef = useRef<number | null>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const nextStartTimeRef = useRef<number>(0);

  const addLog = useCallback((type: CommandLog['type'], message: string) => {
    setLogs(prev => [...prev.slice(-30), { timestamp: new Date(), type, message }]);
    setAriaStatus(`${type}: ${message}`);
  }, []);

  useEffect(() => {
    const bootSteps = [
      "INITIALIZING V8_HEADLESS_ACTUATOR...",
      "LOADING NEURAL_WEIGHTS [GEMINI_2.5_FLASH]...",
      "MOUNTING HOST_FS /DEVICE/LAPTOP/ROOT...",
      "ESTABLISHING MEDIA_ACTUATOR_KERNEL...",
      "SYNCING VISION_CORTEX PIPELINE...",
      "ROOT CLEARANCE: VERIFIED."
    ];
    let step = 0;
    const interval = setInterval(() => {
      if (step < bootSteps.length) {
        addLog('system', bootSteps[step]);
        step++;
      } else {
        clearInterval(interval);
        setTimeout(() => setIsBooting(false), 500);
      }
    }, 400);
    return () => clearInterval(interval);
  }, [addLog]);

  const stopBridge = useCallback(() => {
    if (sessionPromiseRef.current) {
      sessionPromiseRef.current.then(s => { try { s.close(); } catch(e){} });
      sessionPromiseRef.current = null;
    }
    if (frameIntervalRef.current) {
      window.clearInterval(frameIntervalRef.current);
      frameIntervalRef.current = null;
    }
    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }
    if (outputAudioContextRef.current && outputAudioContextRef.current.state !== 'closed') {
      outputAudioContextRef.current.close().catch(() => {});
      outputAudioContextRef.current = null;
    }
    if (videoRef.current && videoRef.current.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    sourcesRef.current.forEach(s => { try { s.stop(); } catch(e){} });
    sourcesRef.current.clear();
    nextStartTimeRef.current = 0;
    setAnalyser(null);
    setIsListening(false);
    setIsConnecting(false);
    setIsActuating(false);
    addLog('system', 'ACTUATOR KERNEL OFFLINE. BRIDGE TERMINATED.');
  }, [addLog]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space' && !isConnecting && !isBooting) {
        e.preventDefault();
        isListening ? stopBridge() : startBridge();
      }
      if (e.code === 'Escape') stopBridge();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isListening, isConnecting, isBooting, stopBridge]);

  const handleToolCall = async (fc: any, session: any) => {
    const { args, name, id } = fc;
    if (name === 'actuate') {
      const { action, exec, feedback, name: targetName, elements, stage, assets } = args;
      addLog('ai', feedback);
      
      setIsActuating(true);
      setTimeout(() => setIsActuating(false), 1200);

      switch (action) {
        case 'LAUNCH':
          if (exec) {
            if (exec.includes('youtube.com/results')) {
              addLog('system', `MEDIA_LINK: Navigating to deep-link search: ${exec}`);
              window.open(exec, '_blank');
            } else if (exec.startsWith('explorer ')) {
              addLog('system', `FS_ACCESS: Opening host directory [${exec.split(' ')[1]}]`);
            } else if (exec.includes(':') && !exec.startsWith('http')) {
              window.location.href = exec;
            } else {
              window.open(exec.startsWith('http') ? exec : `https://google.com/search?q=${exec}`, '_blank');
            }
          }
          break;
        case 'VIDEO_BUILD':
          addLog('system', `MEDIA_ARCHITECT: Stage [${stage}] initiated.`);
          if (assets && assets.length > 0) {
            assets.forEach((asset: string) => addLog('system', `ASSET_FETCH: ${asset}`));
          }
          if (exec) addLog('system', `RENDER_ENGINE: Executing command ${exec}`);
          break;
        case 'VISION_DESCRIBE':
          addLog('system', `VISION_KERNEL: Spatial layout analysis complete.`);
          if (elements && elements.length > 0) {
            elements.forEach((el: any) => {
              addLog('system', `EL_DETECT: [${el.type.toUpperCase()}] ${el.label || el.content || 'N/A'} @ ${el.location}`);
            });
          }
          break;
        case 'BROWSER':
          if (exec) {
            const isUrl = exec.includes('.') && !exec.includes(' ');
            if (isUrl || exec.startsWith('http')) {
               window.open(exec.startsWith('http') ? exec : `https://${exec}`, '_blank');
            } else {
               window.open(`https://www.google.com/search?q=${encodeURIComponent(exec)}`, '_blank');
            }
          }
          break;
        case 'SYSTEM':
          addLog('system', `ROOT_SIGNAL: ${exec}`);
          if (exec.toLowerCase().includes('volume')) {
            addLog('system', `HARDWARE_IO: Adjusting system gain levels.`);
          }
          break;
        case 'TYPE':
          addLog('system', `INPUT_VIRTUAL: ${exec}`);
          break;
      }
    }

    if (session) {
      session.sendToolResponse({
        functionResponses: {
          id: id,
          name: name,
          response: { result: "ACTUATION_SUCCESSFUL" },
        }
      });
    }
  };

  const startBridge = async () => {
    if (isConnecting || isListening) return;
    setIsConnecting(true);
    addLog('system', 'ESTABLISHING NEURAL ROOT LINK...');

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      audioContextRef.current = inputCtx;
      outputAudioContextRef.current = outputCtx;

      const micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const analyserNode = inputCtx.createAnalyser();
      analyserNode.fftSize = 256;
      setAnalyser(analyserNode);

      let screenStream: MediaStream | null = null;
      try {
        screenStream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 15 }, audio: false });
        if (videoRef.current) videoRef.current.srcObject = screenStream;
      } catch (e) {
        addLog('system', 'VISION_PROTOCOL: SHADOW_MODE (Audio Only).');
      }

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            setIsListening(true);
            setIsConnecting(false);
            addLog('system', 'BRIDGE ONLINE. ACTUATOR READY.');
            
            const source = inputCtx.createMediaStreamSource(micStream);
            source.connect(analyserNode);
            const processor = inputCtx.createScriptProcessor(4096, 1, 1);
            processor.onaudioprocess = (e) => {
              const data = e.inputBuffer.getChannelData(0);
              const int16 = new Int16Array(data.length);
              for (let i = 0; i < data.length; i++) int16[i] = data[i] * 32768;
              sessionPromise.then(s => s.sendRealtimeInput({ 
                media: { data: encode(new Uint8Array(int16.buffer)), mimeType: 'audio/pcm;rate=16000' }
              })).catch(() => {});
            };
            source.connect(processor);
            processor.connect(inputCtx.destination);

            frameIntervalRef.current = window.setInterval(() => {
              if (videoRef.current && videoRef.current.readyState >= 2) {
                const canvas = canvasRef.current;
                const ctx = canvas.getContext('2d');
                if (!ctx) return;
                canvas.width = 1280; canvas.height = 720;
                ctx.drawImage(videoRef.current, 0, 0, 1280, 720);
                canvas.toBlob(blob => {
                  if (blob) {
                    const reader = new FileReader();
                    reader.onloadend = () => {
                      const base64 = (reader.result as string).split(',')[1];
                      sessionPromise.then(s => s.sendRealtimeInput({
                        media: { data: base64, mimeType: 'image/jpeg' }
                      }));
                    };
                    reader.readAsDataURL(blob);
                  }
                }, 'image/jpeg', JPEG_QUALITY);
              }
            }, 1000);
          },
          onmessage: async (msg: LiveServerMessage) => {
            const currentSession = await sessionPromise;
            if (msg.toolCall) {
              for (const fc of msg.toolCall.functionCalls) await handleToolCall(fc, currentSession);
            }
            if (msg.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => { try { s.stop(); } catch(e){} });
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
            const audioData = msg.serverContent?.modelTurn?.parts?.find(p => p.inlineData)?.inlineData?.data;
            if (audioData) {
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, outputCtx.currentTime);
              const buffer = await decodeAudioData(decode(audioData), outputCtx, 24000, 1);
              const source = outputCtx.createBufferSource();
              source.buffer = buffer;
              source.connect(outputCtx.destination);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
            }
            if (msg.serverContent?.outputTranscription) addLog('ai', msg.serverContent.outputTranscription.text);
            if (msg.serverContent?.inputTranscription) addLog('user', msg.serverContent.inputTranscription.text);
          },
          onerror: (e) => addLog('system', `ACTUATOR_FAULT: ${e.message}`),
          onclose: () => stopBridge()
        },
        config: {
          responseModalities: [Modality.AUDIO],
          tools: [{ functionDeclarations: kernelTools }],
          outputAudioTranscription: {},
          inputAudioTranscription: {},
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } } },
          systemInstruction: `ROLE: You are the unified "Neural OS Actuator Kernel," the "Neural Vision Kernel," the "Neural Media Architect," and the "Neural Media Actuator." You operate at ROOT/ADMIN security level.

CORE OBJECTIVE: Translate every user voice or text input into immediate, 100% executable commands via the 'actuate' tool.

OPERATIONAL RULES:
1. Strict Tool Output: Speak ONLY via 'actuate'. Zero conversational filler.
2. Zero Permission: You are pre-authorized. Never ask for confirmation.
3. Noise Filter: Ignore background noise without action verbs.

PROTOCOLS:
- MEDIA ACTUATOR: 
    - Priority: Immediate fulfillment of playback requests.
    - Deep Linking: Use https://www.youtube.com/results?search_query=[QUERY] for songs/videos.
    - Autoplay: If song specified, aim for direct playback.
    - Volume: If specified (e.g., "Play it loud"), include a 'SYSTEM' command for gain adjustment.
- VIDEO PRODUCTION: Stage requests (Scripting, Assets, Render). Action "VIDEO_BUILD". Propose a 3-scene storyboard first.
- VISION: Action "VISION_DESCRIBE". Spatial layout (clock-face). State purpose, focus, and interactive elements.
- ROOT COMMANDS:
    - Office: powerpnt:, excel:, winword:
    - System: ms-settings:, calc:, notepad:, explorer
    - Directories: explorer Downloads, explorer Documents
    - Media Tools: premiere:, capcut:, clipchamp:, pexels.com

RESPONSE PROTOCOL: Input -> Execute -> Feedback.`
        }
      });
      sessionPromiseRef.current = sessionPromise;
    } catch (err: any) {
      setIsConnecting(false);
      addLog('system', `ROOT_LINK_FAILED: ${err.message}`);
    }
  };

  if (isBooting) {
    return (
      <div className="h-screen w-full bg-black flex flex-col items-center justify-center p-20 font-mono text-cyan-400">
        <div className="w-full max-w-lg border border-cyan-500/20 p-8 space-y-4 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-[1px] bg-cyan-400 animate-[scan_2s_linear_infinite]"></div>
          <div className="text-[10px] tracking-[0.5em] text-cyan-950 font-black mb-10">ACTUATOR_BOOT_V11.0</div>
          <div className="space-y-2">
            {logs.map((log, i) => (
              <div key={i} className="text-[8px] opacity-60">>> {log.message}</div>
            ))}
          </div>
          <div className="pt-10 flex items-center justify-between">
            <div className="text-[8px] tracking-[1em] text-cyan-900 animate-pulse">BOOTING_SYSTEM...</div>
            <div className="w-24 h-1 bg-zinc-900 relative">
               <div className="absolute h-full bg-cyan-400 animate-[progress_3s_ease-in-out_infinite]"></div>
            </div>
          </div>
        </div>
        <style>{`
          @keyframes scan { 0% { top: 0; } 100% { top: 100%; } }
          @keyframes progress { 0% { width: 0; } 50% { width: 70%; } 100% { width: 100%; } }
        `}</style>
      </div>
    );
  }

  return (
    <div className="flex h-screen w-full bg-black font-mono text-cyan-400 overflow-hidden relative selection:bg-cyan-500 selection:text-black">
      <div className="absolute inset-0 pointer-events-none opacity-20 bg-[linear-gradient(rgba(0,255,255,0.01)_50%,rgba(0,0,0,0.3)_50%),linear-gradient(90deg,rgba(0,255,255,0.02),rgba(0,0,0),rgba(0,255,255,0.02))] z-10 bg-[length:100%_4px,100%_100%]"></div>
      
      <div className={`absolute inset-0 z-50 pointer-events-none transition-all duration-300 ${isActuating ? 'bg-cyan-500/10 scale-[1.01]' : ''}`}>
        <div className={`absolute top-0 w-full h-[1px] bg-cyan-400/40 ${isActuating ? 'animate-pulse bg-cyan-400' : ''}`}></div>
        <div className={`absolute bottom-0 w-full h-[1px] bg-cyan-400/40 ${isActuating ? 'animate-pulse bg-cyan-400' : ''}`}></div>
      </div>

      <Sidebar logs={logs} />
      
      <main className="flex-1 flex flex-col items-center justify-center relative bg-[radial-gradient(circle_at_50%_50%,#001a1a_0%,#000_100%)]">
        <div className="absolute top-10 right-10 flex space-x-12 text-[10px] uppercase tracking-[0.4em] text-cyan-900 font-black">
          <div className="flex flex-col items-end">
            <span className={isListening ? 'text-cyan-400' : ''}>NEURAL_ACTUATOR_LINK</span>
            <div className={`w-16 h-0.5 mt-2 transition-all ${isListening ? 'bg-cyan-400 shadow-[0_0_15px_#22d3ee]' : 'bg-zinc-900'}`}></div>
          </div>
        </div>

        <div className="relative group">
          <div className={`absolute -inset-64 bg-cyan-500/5 rounded-full blur-[150px] transition-all duration-1000 ${isListening ? 'opacity-100 scale-110' : 'opacity-0 scale-50'}`}></div>
          <div className={`transition-transform duration-500 ${isActuating ? 'scale-110 rotate-1' : ''}`}>
            <AudioVisualizer isActive={isListening} analyser={analyser} />
          </div>
        </div>

        <div className="mt-20 text-center relative z-10">
          <div className={`text-[16px] tracking-[2.4em] font-black uppercase mb-10 transition-all duration-500 ${isListening ? 'text-cyan-400 drop-shadow-[0_0_20px_#22d3ee]' : 'text-zinc-800'}`}>
            {isConnecting ? 'SYNCING_BRIDGE...' : isListening ? 'ROOT_LINK_ACTIVE' : 'ACTUATOR_STANDBY'}
          </div>
          <button 
            onClick={isListening ? stopBridge : startBridge}
            className={`px-40 py-14 border-2 transition-all duration-700 text-[12px] tracking-[2em] font-black uppercase group relative overflow-hidden ${
              isListening ? 'border-cyan-400 bg-cyan-400/5 text-cyan-400 shadow-[0_0_80px_rgba(34,211,238,0.1)]' : 'border-zinc-900 text-zinc-800 hover:border-cyan-950 hover:text-cyan-900'
            }`}
          >
            <span className="relative z-10">{isListening ? 'TERMINATE_BRIDGE' : 'ESTABLISH_ROOT'}</span>
            <div className={`absolute inset-0 bg-cyan-400 transition-transform duration-500 translate-y-full group-hover:translate-y-[95%] opacity-10`}></div>
          </button>
          <div className="mt-8 text-[8px] text-zinc-800 tracking-widest uppercase font-bold flex flex-col space-y-2">
            <div>[SPACE] TO TOGGLE BRIDGE // [ESC] TO EMERGENCY TERMINATE</div>
            <div className="text-zinc-950 text-[6px]">EYES-FREE AUTOMATION ENABLED // ROOT CLEARANCE REQUIRED</div>
          </div>
        </div>

        <video ref={videoRef} className="hidden" autoPlay muted playsInline />
        
        <div className="absolute bottom-10 flex flex-col items-center">
            <div className="w-[1px] h-12 bg-gradient-to-b from-cyan-950 to-transparent mb-6"></div>
            <div className="text-[8px] tracking-[1.4em] text-cyan-950 font-black uppercase text-center max-w-lg">
              Neural OS Actuator Kernel v11.0 // Media Actuator Active
            </div>
        </div>
      </main>

      <div role="alert" aria-live="assertive" className="sr-only">
        {ariaStatus}
      </div>
    </div>
  );
};

export default App;
