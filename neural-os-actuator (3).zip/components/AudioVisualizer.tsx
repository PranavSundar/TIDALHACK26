
import React, { useEffect, useRef } from 'react';

interface AudioVisualizerProps {
  isActive: boolean;
  analyser?: AnalyserNode | null;
}

const AudioVisualizer: React.FC<AudioVisualizerProps> = ({ isActive, analyser }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!isActive || !analyser) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);
    let animationId: number;

    const draw = () => {
      animationId = requestAnimationFrame(draw);
      analyser.getByteFrequencyData(dataArray);

      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const barWidth = (canvas.width / 32) - 2;
      let x = 0;

      for (let i = 0; i < 32; i++) {
        // Average a few bins for each of the 32 bars
        const binStart = Math.floor(i * (bufferLength / 64));
        const val = dataArray[binStart];
        const barHeight = (val / 255) * canvas.height;

        ctx.fillStyle = '#22d3ee';
        ctx.shadowBlur = 10;
        ctx.shadowColor = '#22d3ee';
        
        // Center vertically
        const y = (canvas.height - barHeight) / 2;
        ctx.fillRect(x, y, 2, barHeight);

        x += barWidth + 2;
      }
    };

    draw();
    return () => cancelAnimationFrame(animationId);
  }, [isActive, analyser]);

  return (
    <div className="flex items-center justify-center h-16 w-64">
      {isActive ? (
        <canvas 
          ref={canvasRef} 
          width={256} 
          height={64} 
          className="w-full h-full"
        />
      ) : (
        <div className="flex space-x-1">
          {Array.from({ length: 32 }).map((_, i) => (
            <div key={i} className="w-[2px] h-[2px] bg-zinc-900 rounded-full opacity-20"></div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AudioVisualizer;
