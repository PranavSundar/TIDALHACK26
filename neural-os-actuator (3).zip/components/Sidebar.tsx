
import React, { useRef, useEffect, useState } from 'react';
import { CommandLog } from '../types';

interface SidebarProps {
  logs: CommandLog[];
}

const Sidebar: React.FC<SidebarProps> = ({ logs }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [telemetry, setTelemetry] = useState({ cpu: 0, memory: 0, buffer: 0 });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  // Simulate hardware fluctuation
  useEffect(() => {
    const interval = setInterval(() => {
      setTelemetry({
        cpu: Math.floor(Math.random() * 15) + 2,
        memory: 14.2 + (Math.random() * 0.5),
        buffer: Math.floor(Math.random() * 40) + 10
      });
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  return (
    <aside className="w-[480px] bg-[#000505] border-r border-cyan-500/10 flex flex-col p-12 shadow-[50px_0_100px_rgba(0,0,0,0.8)] z-20">
      <div className="flex flex-col mb-12">
        <div className="flex items-center space-x-4 mb-2">
            <div className="w-2 h-2 rounded-none bg-cyan-400 shadow-[0_0_15px_#22d3ee] animate-pulse"></div>
            <span className="text-[11px] font-black text-cyan-400 uppercase tracking-[0.8em]">ROOT_ACTUATOR</span>
        </div>
        <div className="text-[7px] text-cyan-950 font-black uppercase tracking-[0.5em] ml-6 italic">Binary Automation Bridge // V11.0.8</div>
      </div>

      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto space-y-6 font-mono text-[10px] scroll-smooth pr-4 custom-scrollbar"
      >
        {logs.map((log, i) => (
          <div key={i} className={`p-6 rounded-none border-l-2 transition-all duration-300 group hover:bg-cyan-400/5 ${
            log.type === 'system' ? 'bg-black/40 border-zinc-900 text-zinc-600' :
            log.type === 'user' ? 'bg-cyan-500/5 border-cyan-900 text-cyan-400' :
            'bg-cyan-400/10 border-cyan-400 text-white'
          }`}>
            <div className="flex items-center justify-between mb-4">
              <span className={`text-[8px] font-black uppercase tracking-[0.3em] ${
                log.type === 'system' ? 'text-zinc-800' :
                log.type === 'user' ? 'text-cyan-800' :
                'text-cyan-400'
              }`}>
                {log.type === 'system' ? 'KERN_BRIDGE' : log.type.toUpperCase()}
              </span>
              <span className="text-[7px] text-zinc-900 font-black tracking-tighter opacity-40 group-hover:opacity-100">
                {/* Fixed fractionalSecondDigits error by removing it from the options object as it might not be defined in the current TypeScript lib version */}
                {log.timestamp.toLocaleTimeString([], { hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' })}
              </span>
            </div>
            <p className="leading-relaxed opacity-90 font-bold tracking-tight whitespace-pre-wrap selection:bg-cyan-500 selection:text-black">
              {log.message}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-12 pt-10 border-t border-cyan-950/20">
        <h3 className="text-[8px] font-black text-cyan-950 mb-10 uppercase tracking-[1em]">SYSTEM_TELEMETRY</h3>
        <div className="space-y-6 text-[9px] font-mono">
          <div className="flex justify-between items-center">
            <span className="text-zinc-800 uppercase tracking-tighter">Bridge_Latency</span>
            <span className="text-emerald-500 font-black tracking-tighter">0.08 MS</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-zinc-800 uppercase tracking-tighter">CPU_Bridge_Load</span>
            <span className="text-cyan-400 font-black tracking-tighter">{telemetry.cpu}%</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-zinc-800 uppercase tracking-tighter">MEM_Allocation</span>
            <span className="text-cyan-400 font-black tracking-tighter">{telemetry.memory.toFixed(1)} GB</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-zinc-800 uppercase tracking-tighter">Buffer_Saturation</span>
            <span className="text-cyan-400 font-black tracking-tighter">{telemetry.buffer} MB</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-zinc-800 uppercase tracking-tighter">Root_Status</span>
            <span className="text-cyan-400 font-black tracking-tighter">BYPASS_ACTIVE</span>
          </div>
        </div>
      </div>
      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 1px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #083344; }
      `}</style>
    </aside>
  );
};

export default Sidebar;
