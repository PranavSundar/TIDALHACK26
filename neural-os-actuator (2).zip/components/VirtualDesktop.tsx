
// V8 HEADLESS BRIDGE ARCHITECTURE: Virtual components removed to force real-world host interaction.
export default null;
